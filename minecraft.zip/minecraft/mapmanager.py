class Mapmanager():
    def __init__(self):
        self.model = "block"
        self.texture = "block.png"
        self.color = (0.2,0.2 , 0.35,1)
        self.startNew()
        self.addblock((0,10,0))

    def startNew(self):
        self.land = self.render.attachNewNode("Land")
    
    def addBlock(self, position):
        self.block  = self.loader.loadModel(self.model)
        self.block.setTexute(self.loader.loadTexure(self.texture))
        self.block.setPos(position)
        self.block.setColor(self.color)
        self.block.reaprentTo(self.land)



