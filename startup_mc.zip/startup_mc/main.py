import pandas as pd
from itertools import combinations
import matplotlib.pyplot as plt

# --- Завантаження CSV ---
df = pd.read_csv("menu.csv")

# --- Норми ---
daily_calories = 2000
max_fat_ratio = 0.3
fat_calories_limit = daily_calories * max_fat_ratio
fat_grams_limit = fat_calories_limit / 9

# --- Ліміти на прийоми їжі ---
limits = {
    "breakfast": 600,
    "lunch": 700,
    "dinner": 700
}

# --- Фіксована кава ---
coffee = {
    'Item': 'Coffee (Fixed)',
    'Calories': 130,
    'Total Fat': 3,
    'Protein': 1,
    'Carbohydrates': 10
}

# --- Фільтр категорій ---
def filter_group(df, keyword):
    return df[df['Category'].str.contains(keyword, case=False, na=False)][['Item', 'Calories', 'Total Fat', 'Protein', 'Carbohydrates']]

breakfast_items = filter_group(df, "Breakfast")
lunch_items = filter_group(df, "Lunch|Beef|Chicken|Burger|Salad|Wrap")
dinner_items = filter_group(df, "Dinner|Burger|Chicken|Beef|Wrap|Salad")

# --- Перевірка здорової комбінації ---
def is_healthy(combo, cal_limit):
    total_calories = sum(item['Calories'] for item in combo)
    total_fat = sum(item['Total Fat'] for item in combo)
    fat_calories = total_fat * 9
    if total_calories == 0:
        return False
    fat_ratio = fat_calories / total_calories
    return total_calories <= cal_limit and fat_ratio <= max_fat_ratio

# --- Пошук комбінацій ---
def find_combos(items, cal_limit):
    items = items.to_dict(orient='records')
    valid = []
    for r in range(1, 4):
        for combo in combinations(items, r):
            combo_list = list(combo)
            if cal_limit == limits['breakfast']:  # додати каву до сніданку
                combo_list = combo_list + [coffee]
            if is_healthy(combo_list, cal_limit):
                valid.append(combo_list)
    return valid

# --- Комбінації для здорового меню ---
breakfast_combos = find_combos(breakfast_items, limits['breakfast'])[:3]
lunch_combos = find_combos(lunch_items, limits['lunch'])[:3]
dinner_combos = find_combos(dinner_items, limits['dinner'])[:3]

# --- Формування здорових денних меню ---
daily_menus = []
for b_combo in breakfast_combos:
    for l_combo in lunch_combos:
        for d_combo in dinner_combos:
            full_day = b_combo + l_combo + d_combo
            total_cals = sum(i['Calories'] for i in full_day)
            total_fat = sum(i['Total Fat'] for i in full_day)
            total_prot = sum(i['Protein'] for i in full_day)
            total_carb = sum(i['Carbohydrates'] for i in full_day)
            if total_cals <= daily_calories and total_fat <= fat_grams_limit:
                daily_menus.append((b_combo, l_combo, d_combo, total_cals, total_fat, total_prot, total_carb))

# --- Вивід перших 3 здорових меню ---
for idx, (b, l, d, cals, fat, prot, carb) in enumerate(daily_menus[:3], start=1):
    print(f"\n🍱 Меню №{idx} | Калорії: {cals} | Жири: {fat:.1f} г | Білки: {prot:.1f} г | Вуглеводи: {carb:.1f} г")
    print("🥣 Сніданок:")
    for i in b:
        print(f" - {i['Item']} ({i['Calories']} ккал)")
    print("🍛 Обід:")
    for i in l:
        print(f" - {i['Item']} ({i['Calories']} ккал)")
    print("🍽️ Вечеря:")
    for i in d:
        print(f" - {i['Item']} ({i['Calories']} ккал)")

# --- Калорії здорового меню ---
first_day_calories = daily_menus[0][3]
second_day_calories = daily_menus[1][3]
third_day_calories = daily_menus[2][3]

s_healthy = pd.Series(data=[first_day_calories, second_day_calories, third_day_calories], index=[1, 2, 3])
s_healthy.plot(kind="bar", color="green", edgecolor="black")
plt.xlabel("День")
plt.ylabel("Калорії")
plt.title("Калорії в здоровому раціоні (3 дні)")
plt.tight_layout()
plt.show()

# --- Створення поганого меню на 3 дні ---
bad_breakfast_items = [
    'Sausage, Egg & Cheese McGriddles',
    'Hash Brown',
    'Caramel Iced Coffee (Large)'
]

bad_lunch_items = [
    'Big Mac',
    'Large French Fries',
    'Coca-Cola Classic (Large)'
]

bad_dinner_items = [
    'Double Quarter Pounder with Cheese',
    'Chocolate Shake (Large)',
    'Baked Apple Pie'
]

def get_items(items_list):
    found_items = []
    for name in items_list:
        item_row = df[df['Item'].str.lower() == name.lower()]
        if not item_row.empty:
            item_dict = item_row.iloc[0][['Item', 'Calories', 'Total Fat', 'Protein', 'Carbohydrates']].to_dict()
            found_items.append(item_dict)
        else:
            print(f"⚠️ Попередження: '{name}' не знайдено в menu.csv!")
    return found_items

bad_breakfast = get_items(bad_breakfast_items)
bad_lunch = get_items(bad_lunch_items)
bad_dinner = get_items(bad_dinner_items)

bad_day_total_cals = []
for day in range(3):
    day_meal = bad_breakfast + bad_lunch + bad_dinner
    total_cals = sum(item['Calories'] for item in day_meal)
    bad_day_total_cals.append(total_cals)

s_bad = pd.Series(data=bad_day_total_cals, index=[1, 2, 3])
s_bad.plot(kind="bar", color="red", edgecolor="black")
plt.xlabel("День")
plt.ylabel("Калорії")
plt.title("Калорії в поганому раціоні (3 дні Макдональдс)")
plt.tight_layout()
plt.show()

# --- Вивід поганого меню для кожного з 3 днів ---
for day in range(1, 4):
    total_cals = sum(item['Calories'] for item in bad_breakfast + bad_lunch + bad_dinner)
    total_fat = sum(item['Total Fat'] for item in bad_breakfast + bad_lunch + bad_dinner)
    total_prot = sum(item['Protein'] for item in bad_breakfast + bad_lunch + bad_dinner)
    total_carb = sum(item['Carbohydrates'] for item in bad_breakfast + bad_lunch + bad_dinner)
    
    print(f"\n🔥 Погане меню №{day} | Калорії: {total_cals} | Жири: {total_fat:.1f} г | "
          f"Білки: {total_prot:.1f} г | Вуглеводи: {total_carb:.1f} г")
    
    print("🥣 Сніданок:")
    for i in bad_breakfast:
        print(f" - {i['Item']} ({i['Calories']} ккал)")
        
    print("🍔 Обід:")
    for i in bad_lunch:
        print(f" - {i['Item']} ({i['Calories']} ккал)")
        
    print("🍽️ Вечеря:")
    for i in bad_dinner:
        print(f" - {i['Item']} ({i['Calories']} ккал)")


# Функція для підрахунку калорій у наборі страв
def combo_calories(combo):
    return sum(item['Calories'] for item in combo)

# Візьмемо першу комбінацію зі здорового меню для кожного прийому
breakfast_calories = combo_calories(breakfast_combos[0])
lunch_calories = combo_calories(lunch_combos[0])
dinner_calories = combo_calories(dinner_combos[0])

# Дані для графіків
meals = ['Сніданок', 'Обід', 'Вечеря']
calories = [breakfast_calories, lunch_calories, dinner_calories]
limits_for_meals = [limits['breakfast'], limits['lunch'], limits['dinner']]

import numpy as np

fig, ax = plt.subplots(figsize=(8,5))
bars = ax.bar(meals, calories, color='blue', edgecolor='black')

# Додамо горизонтальні лінії лімітів калорій
for i, limit in enumerate(limits_for_meals):
    ax.hlines(limit, i-0.4, i+0.4, colors='red', linestyles='dashed', label='Ліміт калорій' if i==0 else "")

# Підписи на стовпчиках
for bar in bars:
    height = bar.get_height()
    ax.text(bar.get_x() + bar.get_width()/2, height + 10, f'{int(height)} ккал', ha='center', fontsize=11)

# Підписи і заголовок
ax.set_ylabel('Калорії (ккал)', fontsize=12)
ax.set_title("Калорії наборів McDonald's, які не перевищують норму калорій для прийому їжі", fontsize=14, fontweight='bold')
ax.legend()
plt.tight_layout()
plt.show()
