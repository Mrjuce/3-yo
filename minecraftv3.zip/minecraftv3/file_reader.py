count_ones = 0
total_sum = 0
item = None

with open("my_file.txt", "r") as file:
    for i, line in enumerate(file):
        # 1. Підрахунок кількості символів "1"
        count_ones += line.count("1")

        # 2. Якщо це 14-й рядок (індекс 13)
        if i == 13:
            parts = line.split()
            if len(parts) > 7 and parts[7].isdigit():
                item = int(parts[7])

        # 3. Додаємо всі числа в рядку
        for num in line.split():
            if num.isdigit():
                total_sum += int(num)

print("Кількість '1':", count_ones)
print("Елемент з рядка 14, позиція 8:", item)
print("Сума всіх чисел:", total_sum)
