key_switch_camera = "c"
key_switch_mode = "z"

key_forward = "w"
key_back = "s"
key_left = "a"
key_right = "d"
key_up = "e"
key_down = "q"

key_turn_left = "n"
key_turn_right = "m"

key_build = "b"
key_derstoy = "v"

class Hero():
    def __init__(self, pos, land):
        self.land = land
        self.mode = True
        self.hero = self.loader.loadModel("smiley")
        self.hero.setColor(1,0.5,0)
        self.hero.setScale(0.3)
        self.hero.setH(180)
        self.hero.setPos(pos)
        self.hero.reparentTo(self.render)
        self.cameraBind()
        self.accept_events()

    def cameraBind(self):
        base.disableMouse()
        base.camera.reparentTo(self.hero)
        base.camera.setPos(0,0,1.5)
        self.cameraOn= True

    def cameraUp(self):
        pos = self.hero.getPos()
        base.mouseInterfaceNode.setPos(-pos[0], -pos[1], -pos[2] - 3)
        base.camera.reparentTo(self.render)
        base.enableMouse()
        self.cameraOn = False


    def changeView(self):
        if self.cameraOn:
            self.cameraUp()
        else:
            self.cameraBind()

    def turn_left(self):
        self.hero.setH((self.hero.getH() + 5) %360)

    def turn_right(self):
        self.hero.setH((self.hero.getH() - 5) %360)

    def look_at(self,angle):
        x_from = round(self.hero.getX())
        y_from = round(self.hero.getY())
        z_from = round(self.hero.getZ())

        dx,dy = self.check_dir(angle)
        x_to = x_from + dx
        y_to = x_from + dy
        return x_to, y_to, z_from
    
    def just_move(self,angle):
        pos = self.look_at(angle)
        self.hero.setPos()


    def move_to(self,angle):
        if self.mode:
            self.just_move(angle)
        else:
            self.try_move(angle)

    def forward(self):
        angle = (self.hero.getH()) % 360
        self.move_to(angle)


    def back(self):
        angle = (self.hero.getH() +180) % 360
        self.move_to(angle)


    def left(self):
        angle = (self.hero.getH() +90) % 360
        self.move_to(angle)

    def forward(self):
        angle = (self.hero.getH() +270) % 360
        self.move_to(angle)
