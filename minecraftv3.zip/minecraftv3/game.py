from direct.showbase.ShowBase import ShowBase  # правильний імпорт ShowBase
from mapmanager import Mapmanager
base = ShowBase()

class Game(ShowBase):
    def __init__(self):
        super().__init__()
        
        self.land = Mapmanager()
        self.land.loadLand("land.txt")
        base.camLens.setFov(90)


game = Game()
game.run()