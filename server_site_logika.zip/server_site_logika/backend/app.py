from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from models import db, User, Transaction
from ai_logic import analyze_query

app=Flask(__name__)
CORS(app)

app.config["SQLALCHEMY_DATABASE_URI"]="sqlite:///finmanager.db"
app.config["JWT_SECRET_KEY"]="change-this"
db.init_app(app)
jwt=JWTManager(app)

@app.post("/register")
def register():
    data=request.json
    if User.query.filter_by(email=data["email"]).first():
        return jsonify({"error":"Email вже зайнятий"}),400
    user=User(login=data["login"],name=data["name"],email=data["email"],password=data["password"])
    db.session.add(user); db.session.commit()
    return jsonify({"message":"OK"})

@app.post("/login")
def login():
    data=request.json
    user=User.query.filter_by(email=data["email"]).first()
    if not user or user.password!=data["password"]:
        return jsonify({"error":"Невірний логін або пароль"}),401
    return jsonify({"token":create_access_token(identity=user.id)})

@app.post("/add-transaction")
@jwt_required()
def add_transaction():
    user_id=get_jwt_identity()
    d=request.json
    tx=Transaction(user_id=user_id,type=d["type"],amount=d["amount"],category=d["category"],
                   date=d["date"],description=d.get("description",""),tags=",".join(d.get("tags",[])))
    db.session.add(tx); db.session.commit()
    return jsonify({"message":"OK"})

@app.get("/get-transactions")
@jwt_required()
def get_transactions():
    user_id=get_jwt_identity()
    txs=Transaction.query.filter_by(user_id=user_id).all()
    return jsonify([
        {"id":t.id,"type":t.type,"amount":t.amount,"category":t.category,
         "date":t.date,"description":t.description,"tags":t.tags.split(",") if t.tags else []}
        for t in txs
    ])

@app.post("/ai")
@jwt_required()
def ai():
    user_id=get_jwt_identity()
    q=request.json.get("query","")
    txs=Transaction.query.filter_by(user_id=user_id).all()
    return jsonify({"answer":analyze_query(q,txs)})

if __name__=="__main__":
    with app.app_context(): db.create_all()
    app.run(debug=True)
