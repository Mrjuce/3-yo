def analyze_query(query,transactions):
    q=(query or "").lower()
    if "баланс" in q:
        inc=sum(t.amount for t in transactions if t.type=="income")
        exp=sum(t.amount for t in transactions if t.type=="expense")
        return f"Ваш баланс: {inc-exp} грн"
    if "найбільш" in q:
        exps=[t for t in transactions if t.type=="expense"]
        if not exps: return "Витрат не знайдено."
        b=max(exps,key=lambda t:t.amount)
        return f"Найбільша витрата: {b.amount} грн"
    if "витратив" in q:
        total=sum(t.amount for t in transactions if t.type=="expense")
        return f"Всього витрат: {total} грн"
    return "Не знаю, як відповісти."
