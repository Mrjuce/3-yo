from flask_sqlalchemy import SQLAlchemy
db=SQLAlchemy()

class User(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    login=db.Column(db.String(50))
    name=db.Column(db.String(50))
    email=db.Column(db.String(120),unique=True)
    password=db.Column(db.String(120))

class Transaction(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    user_id=db.Column(db.Integer)
    type=db.Column(db.String(20))
    amount=db.Column(db.Float)
    category=db.Column(db.String(50))
    date=db.Column(db.String(20))
    description=db.Column(db.String(250))
    tags=db.Column(db.String(250))
