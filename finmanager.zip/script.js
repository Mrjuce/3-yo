// --- FIREBASE IMPORTS (Тільки для використання у Canvas) ---
        import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-app.js";
        import { getAuth, signInAnonymously, signInWithCustomToken, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-auth.js";
        import { getFirestore, collection, query, addDoc, deleteDoc, onSnapshot, doc, getDocs } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";
        
        // --- GLOBAL FIREBASE/APP VARIABLES ---
        let db;
        let auth;
        let unsubscribeFromTransactions = null; 

        // --- ВИЗНАЧЕННЯ СЕРЕДОВИЩА ---
        const IS_CANVAS_ENVIRONMENT = typeof __initial_auth_token !== 'undefined';
        const MOCK_USER_ID = crypto.randomUUID(); // Унікальний ID для локального режиму
        
        // Налаштування конфігурації відповідно до середовища
        const appId = IS_CANVAS_ENVIRONMENT ? (typeof __app_id !== 'undefined' ? __app_id : 'default-canvas-app-id') : 'local-mock-app-id';
        const firebaseConfig = IS_CANVAS_ENVIRONMENT ? JSON.parse(__firebase_config) : {};
        const initialAuthToken = IS_CANVAS_ENVIRONMENT ? __initial_auth_token : null;


        // --- UTILITY: NON-BLOCKING MESSAGES (REPLACES ALERT/CONFIRM) ---
        window.showNonBlockingMessage = (text, type = 'success') => {
            const container = document.getElementById('messageContainer');
            const colorMap = {
                success: 'bg-emerald-500',
                info: 'bg-blue-500',
                error: 'bg-rose-500'
            };
            const messageEl = document.createElement('div');
            messageEl.className = `p-3 rounded-lg text-white font-medium shadow-xl ${colorMap[type]} transition-opacity duration-300 opacity-0 transform translate-y-2 max-w-xs`;
            messageEl.textContent = text;
            
            container.appendChild(messageEl);

            // Animate in
            setTimeout(() => {
                messageEl.classList.remove('opacity-0', 'translate-y-2');
                messageEl.classList.add('opacity-100', 'translate-y-0');
            }, 10);

            // Animate out and remove
            setTimeout(() => {
                messageEl.classList.remove('opacity-100', 'translate-y-0');
                messageEl.classList.add('opacity-0', 'translate-y-2');
                setTimeout(() => messageEl.remove(), 300);
            }, 3000);
        }

        // --- DATA STORE & STATE ---
        const state = {
            transactions: [], 
            userId: null,
            isAuthReady: false,
            categories: {
                income: ['Зарплата', 'Фріланс', 'Подарунок', 'Інвестиції'],
                expense: ['Їжа', 'Транспорт', 'Житло', 'Освіта', 'Дозвілля', 'Здоров\'я', 'Техніка', 'Інше']
            }
        };

        // Pagination and Filter State
        let currentPage = 1;
        const transactionsPerPage = 10;
        let currentFilter = {
            search: '',
            type: 'all',
            category: 'all'
        };

        // --- MOCK / LIVE DATA HANDLING ---

        // Обгортка для onSnapshot (повертає функцію відписки)
        function listenForTransactions(callback) {
            if (IS_CANVAS_ENVIRONMENT && db && state.userId) {
                const transactionsRef = collection(db, 'artifacts', appId, 'users', state.userId, 'transactions');
                const q = query(transactionsRef); 
                return onSnapshot(q, (snapshot) => {
                    const transactions = [];
                    snapshot.forEach(doc => {
                        const data = doc.data();
                        const date = data.date?.toDate ? data.date.toDate().toISOString().split('T')[0] : data.date;
                        transactions.push({ id: doc.id, date, type: data.type, category: data.category, amount: data.amount, note: data.note });
                    });
                    transactions.sort((a, b) => new Date(b.date) - new Date(a.date));
                    callback(transactions);
                }, (error) => {
                    console.error("Error setting up transaction listener:", error);
                    showNonBlockingMessage(`Помилка завантаження даних: ${error.message}`, 'error');
                });
            } else {
                // MOCK MODE: Повертаємо заглушку функції відписки
                const mockListener = () => {
                    console.log("Mock Listener triggered. Using in-memory data.");
                    const transactions = [...state.transactions]; // Повертаємо копію
                    transactions.sort((a, b) => new Date(b.date) - new Date(a.date));
                    callback(transactions);
                };
                // Ініціалізуємо mock-даними та запускаємо слухача
                state.transactions = getSampleData().map(t => ({...t, id: crypto.randomUUID()}));
                mockListener();
                return () => console.log("Mock listener unsubscribed."); 
            }
        }
        
        // Обгортка для addDoc
        async function addTransaction(newTransaction) {
            if (IS_CANVAS_ENVIRONMENT && db && state.userId) {
                const transactionsRef = collection(db, 'artifacts', appId, 'users', state.userId, 'transactions');
                await addDoc(transactionsRef, newTransaction);
            } else {
                // MOCK MODE: Додавання в пам'ять
                const id = crypto.randomUUID();
                state.transactions.push({ ...newTransaction, id });
                // Імітація оновлення через onSnapshot
                setupRealtimeListener(); 
            }
        }

        // Обгортка для deleteDoc
        async function deleteTransactionDoc(docId) {
            if (IS_CANVAS_ENVIRONMENT && db && state.userId) {
                const docRef = doc(db, 'artifacts', appId, 'users', state.userId, 'transactions', docId);
                await deleteDoc(docRef);
            } else {
                // MOCK MODE: Видалення з пам'яті
                state.transactions = state.transactions.filter(t => t.id !== docId);
                // Імітація оновлення через onSnapshot
                setupRealtimeListener();
            }
        }

        // --- FIREBASE INITIALIZATION & AUTH ---

        async function initFirebase() {
            const loaderTitle = document.getElementById('loader-title');
            const loaderStatus = document.getElementById('loader-status');
            const dataSourceInfo = document.getElementById('data-source-info');

            // --- LOCAL MOCK MODE SETUP ---
            if (!IS_CANVAS_ENVIRONMENT) {
                console.log("Running in Local Mock Mode (Firebase simulation).");
                loaderTitle.textContent = 'Локальний Режим (Симуляція)';
                loaderStatus.textContent = 'Дані завантажено з пам\'яті.';
                dataSourceInfo.textContent = 'з пам\'яті (Mock Mode).';
                
                state.userId = MOCK_USER_ID;
                state.isAuthReady = true;
                document.getElementById('auth-status').textContent = 'Локальний Mock';
                document.getElementById('user-id-display').textContent = MOCK_USER_ID;

                // Запуск mock-слухача з початковими даними
                setupRealtimeListener(); 
                
                // Приховуємо завантажувач
                document.getElementById('full-page-loader').classList.add('hidden');
                showNonBlockingMessage('Локальний режим активовано. Дані не зберігаються.', 'info');
                return;
            }

            // --- CANVAS LIVE MODE SETUP ---
            try {
                loaderTitle.textContent = 'Підключення до Firestore...';
                const app = initializeApp(firebaseConfig);
                db = getFirestore(app);
                auth = getAuth(app);

                loaderStatus.textContent = 'Виконання автентифікації...';

                await signInWithCustomToken(auth, initialAuthToken);
                
                // Запуск слухача автентифікації
                onAuthStateChanged(auth, (user) => {
                    if (user) {
                        state.userId = user.uid;
                        state.isAuthReady = true;
                        document.getElementById('auth-status').textContent = 'Активний (Firestore)';
                        document.getElementById('user-id-display').textContent = user.uid;
                        loaderStatus.textContent = 'Завантаження даних у реальному часі...';
                        
                        setupRealtimeListener();
                    } else {
                        throw new Error("User state is unexpectedly null after sign-in.");
                    }
                });

            } catch (error) {
                console.error("Firebase initialization or sign-in error:", error);
                document.getElementById('auth-status').textContent = `Помилка: ${error.code || error.message}`;
                loaderStatus.textContent = `Помилка: Не вдалося підключитися. ${error.message}`;
                showNonBlockingMessage(`Помилка підключення: ${error.message}`, 'error');
            }
        }

        function setupRealtimeListener() {
            if (!state.isAuthReady) return;

            const loader = document.getElementById('full-page-loader');

            // Якщо слухач вже існує, відписуємося
            if (unsubscribeFromTransactions) {
                unsubscribeFromTransactions();
            }
            
            // Викликаємо універсальну функцію
            unsubscribeFromTransactions = listenForTransactions((transactions) => {
                state.transactions = transactions;
                
                // Оновлюємо весь UI після отримання нових даних
                renderKpiCards();
                renderTopExpenses();
                updateCharts();
                applyFilters(); // Це також викликає renderTransactions()
                
                // Приховуємо завантажувач
                if (loader && !loader.classList.contains('hidden')) {
                    loader.classList.add('hidden');
                    if(IS_CANVAS_ENVIRONMENT) {
                        showNonBlockingMessage('Дані успішно завантажено з Firestore!', 'success');
                    }
                }
            });
        }


        // --- NAVIGATION (No change) ---
        function switchView(viewId) {
            document.querySelectorAll('[id^="view-"]').forEach(el => el.classList.add('hidden'));
            document.getElementById(`view-${viewId}`).classList.remove('hidden');
            
            document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));
            const activeNav = document.getElementById(`nav-${viewId}`);
            if(activeNav) activeNav.classList.add('active');

            if(viewId === 'dashboard') {
                updateCharts();
                renderKpiCards();
                renderTopExpenses();
            }
            if(viewId === 'transactions') {
                renderTransactions();
            }
        }

        window.switchView = switchView; 

        function toggleMobileMenu() {
            const menu = document.getElementById('mobile-menu');
            menu.classList.toggle('hidden');
        }

        // --- TRANSACTION LOGIC ---

        function populateCategorySelects() {
            const filters = document.getElementById('categoryFilter');
            const form = document.getElementById('formCategorySelect');
            
            filters.innerHTML = '<option value="all">Всі категорії</option>';
            form.innerHTML = '<option value="" disabled selected>Виберіть категорію</option>';

            const allCategories = [...new Set([...state.categories.income, ...state.categories.expense])].sort();

            allCategories.forEach(cat => {
                const optionFilter = new Option(cat, cat);
                const optionForm = new Option(cat, cat);
                filters.appendChild(optionFilter);
                form.appendChild(optionForm);
            });
        }

        function getFilteredAndPaginatedTransactions() {
            let filtered = state.transactions
                .filter(t => currentFilter.type === 'all' || t.type === currentFilter.type)
                .filter(t => currentFilter.category === 'all' || t.category === currentFilter.category)
                .filter(t => t.note.toLowerCase().includes(currentFilter.search.toLowerCase()));

            // Total filtered count
            const totalCount = filtered.length;
            const totalPages = Math.ceil(totalCount / transactionsPerPage);

            // Apply pagination
            const start = (currentPage - 1) * transactionsPerPage;
            const end = start + transactionsPerPage;
            
            return {
                data: filtered.slice(start, end),
                totalCount: totalCount,
                totalPages: totalPages
            };
        }

        function renderTransactions() {
            const { data, totalCount, totalPages } = getFilteredAndPaginatedTransactions();
            const tbody = document.getElementById('transactionsBody');
            tbody.innerHTML = '';

            const start = (currentPage - 1) * transactionsPerPage + 1;
            const end = Math.min(start + data.length - 1, totalCount);

            document.getElementById('paginationInfo').textContent = `Показано ${start}-${end} з ${totalCount} записів`;
            document.getElementById('prevPageBtn').disabled = currentPage === 1;
            document.getElementById('nextPageBtn').disabled = currentPage >= totalPages;

            if (data.length === 0) {
                tbody.innerHTML = '<tr><td colspan="6" class="px-6 py-8 text-center text-stone-500">Записів за заданими фільтрами не знайдено.</td></tr>';
                return;
            }

            data.forEach(t => {
                const isIncome = t.type === 'income';
                const row = document.createElement('tr');
                row.className = 'hover:bg-stone-50 transition-colors border-b border-stone-50';
                
                let iconClass = 'fa-circle-question';
                if(t.category === 'Їжа') iconClass = 'fa-utensils';
                else if(t.category === 'Транспорт') iconClass = 'fa-car';
                else if(t.category === 'Житло') iconClass = 'fa-house';
                else if(t.category === 'Зарплата' || t.category === 'Фріланс') iconClass = 'fa-money-bill-wave';
                else if(t.category === 'Освіта') iconClass = 'fa-graduation-cap';
                else if(t.category === 'Дозвілля') iconClass = 'fa-film';
                else if(t.category === 'Здоров\'я') iconClass = 'fa-heart-pulse';
                else if(t.category === 'Техніка') iconClass = 'fa-laptop';

                const badgeColor = isIncome ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700';
                const amountColor = isIncome ? 'text-emerald-600' : 'text-stone-800';
                const sign = isIncome ? '+' : '-';

                row.innerHTML = `
                    <td class="px-6 py-4">
                        <span class="text-xs font-bold px-2 py-1 rounded ${badgeColor}">
                            ${isIncome ? 'Дохід' : 'Витрата'}
                        </span>
                    </td>
                    <td class="px-6 py-4 flex items-center gap-3">
                        <div class="w-8 h-8 rounded bg-stone-100 text-stone-500 flex items-center justify-center">
                            <i class="fa-solid ${iconClass}"></i>
                        </div>
                        <span class="font-medium text-stone-700">${t.category}</span>
                    </td>
                    <td class="px-6 py-4 text-stone-500">${t.date}</td>
                    <td class="px-6 py-4 text-stone-500">${t.note}</td>
                    <td class="px-6 py-4 text-right font-bold ${amountColor}">${sign}${t.amount.toLocaleString('uk-UA', { minimumFractionDigits: 2 })} ₴</td>
                    <td class="px-6 py-4 text-center">
                        <button onclick="deleteTransaction('${t.id}')" class="text-stone-400 hover:text-rose-500 transition-colors"><i class="fa-solid fa-trash"></i></button>
                    </td>
                `;
                tbody.appendChild(row);
            });
        }

        // ФУНКЦІЯ ВИДАЛЕННЯ: Викликає універсальну обгортку
        window.deleteTransaction = async (docId) => {
            if (!state.isAuthReady) {
                 showNonBlockingMessage('Система не готова.', 'error');
                 return;
            }

            try {
                await deleteTransactionDoc(docId);
                showNonBlockingMessage('Транзакцію успішно видалено.', 'success');
            } catch (error) {
                console.error("Error deleting document:", error);
                showNonBlockingMessage(`Помилка видалення: ${error.message}`, 'error');
            }
        }

        window.applyFilters = applyFilters;
        function applyFilters() {
            currentFilter.search = document.getElementById('searchFilter').value.trim();
            currentFilter.type = document.getElementById('typeFilter').value;
            currentFilter.category = document.getElementById('categoryFilter').value;
            currentPage = 1; // Reset to first page after applying new filters
            renderTransactions();
        }

        window.paginateTransactions = paginateTransactions;
        function paginateTransactions(direction) {
            const { totalPages } = getFilteredAndPaginatedTransactions();
            const newPage = currentPage + direction;
            if (newPage >= 1 && newPage <= totalPages) {
                currentPage = newPage;
                renderTransactions();
            }
        }
        
        window.toggleAddForm = toggleAddForm;
        function toggleAddForm() {
            const formContainer = document.getElementById('addFormContainer');
            formContainer.classList.toggle('hidden');
        }

        // ФУНКЦІЯ ДОДАВАННЯ: Викликає універсальну обгортку
        async function submitNewTransaction(event) {
            event.preventDefault();
            
            if (!state.isAuthReady) {
                 showNonBlockingMessage('Система не готова. Спробуйте пізніше.', 'error');
                 return;
            }

            const form = event.target;
            const formData = new FormData(form);
            const amountValue = formData.get('amount');
            const amountFloat = parseFloat(amountValue);

            if (!amountValue || isNaN(amountFloat) || amountFloat <= 0) {
                showNonBlockingMessage('Будь ласка, введіть коректну позитивну суму.', 'error');
                return;
            }

            const newTransaction = {
                date: formData.get('date'),
                type: formData.get('type'),
                category: formData.get('category'),
                amount: amountFloat,
                note: formData.get('note') || 'Без нотатки',
            };

            try {
                await addTransaction(newTransaction);
                
                form.reset();
                toggleAddForm(); 
                showNonBlockingMessage(`Транзакцію додано: ${newTransaction.note} (${newTransaction.amount.toLocaleString('uk-UA', { minimumFractionDigits: 2 })} ₴)`, 'success');
            } catch (error) {
                console.error("Error adding document:", error);
                showNonBlockingMessage(`Помилка додавання: ${error.message}`, 'error');
            }
        }

        // --- SAMPLE DATA & SEEDING ---

        function getFormattedDate(offsetDays) {
            const date = new Date();
            date.setDate(date.getDate() - offsetDays);
            return date.toISOString().split('T')[0];
        }

        function getSampleData() {
            return [
                // Доходи
                { date: getFormattedDate(30), type: 'income', category: 'Зарплата', amount: 35000.00, note: 'Зарплата за минулий місяць' },
                { date: getFormattedDate(15), type: 'income', category: 'Фріланс', amount: 5500.00, note: 'Оплата за проєкт "Landing Page"' },
                { date: getFormattedDate(5), type: 'income', category: 'Подарунок', amount: 1500.00, note: 'Подарунок на день народження' },
                
                // Витрати
                { date: getFormattedDate(28), type: 'expense', category: 'Житло', amount: 12000.00, note: 'Оренда квартири + комунальні послуги' },
                { date: getFormattedDate(27), type: 'expense', category: 'Їжа', amount: 2500.00, note: 'Продукти з супермаркету' },
                { date: getFormattedDate(25), type: 'expense', category: 'Техніка', amount: 8999.00, note: 'Новий монітор для роботи' },
                { date: getFormattedDate(20), type: 'expense', category: 'Транспорт', amount: 550.00, note: 'Поповнення проїзного' },
                { date: getFormattedDate(18), type: 'expense', category: 'Дозвілля', amount: 800.00, note: 'Квитки в кіно та попкорн' },
                { date: getFormattedDate(10), type: 'expense', category: 'Їжа', amount: 1200.00, note: 'Вечеря в ресторані' },
                { date: getFormattedDate(8), type: 'expense', category: 'Освіта', amount: 199.00, note: 'Підписка на онлайн-курс' },
                { date: getFormattedDate(3), type: 'expense', category: 'Здоров\'я', amount: 450.00, note: 'Ліки в аптеці' },
                { date: getFormattedDate(1), type: 'expense', category: 'Інше', amount: 200.00, note: 'Дрібна канцелярія' }
            ];
        }


        window.seedDatabase = async () => {
             if (!state.isAuthReady) {
                 showNonBlockingMessage('Система не готова.', 'error');
                 return;
            }

            const dataToSeed = getSampleData();
            showNonBlockingMessage(`Початок заповнення бази даних ${dataToSeed.length} тестовими записами...`, 'info');
            
            if (IS_CANVAS_ENVIRONMENT) {
                const transactionsRef = collection(db, 'artifacts', appId, 'users', state.userId, 'transactions');
                const promises = dataToSeed.map(data => addDoc(transactionsRef, data).catch(e => {
                    console.error("Error seeding document:", data, e);
                    return null; 
                }));
                await Promise.all(promises);
            } else {
                // MOCK MODE: Замінюємо поточні дані на тестові
                state.transactions = dataToSeed.map(t => ({...t, id: crypto.randomUUID()}));
                // Оновлення UI
                setupRealtimeListener();
            }

            showNonBlockingMessage('Базу даних успішно заповнено тестовими даними!', 'success');
        }


        // --- DASHBOARD LOGIC (Updated to use dynamic state.transactions) ---

        function calculateKpi() {
            const totalIncome = state.transactions
                .filter(t => t.type === 'income')
                .reduce((sum, t) => sum + t.amount, 0);

            const totalExpense = state.transactions
                .filter(t => t.type === 'expense')
                .reduce((sum, t) => sum + t.amount, 0);
            
            return { totalIncome, totalExpense, balance: totalIncome - totalExpense };
        }

        function renderKpiCards() {
            const { totalIncome, totalExpense, balance } = calculateKpi();
            const cardsContainer = document.getElementById('kpi-cards');

            const formatter = new Intl.NumberFormat('uk-UA', { minimumFractionDigits: 2 });

            const dataOrigin = IS_CANVAS_ENVIRONMENT ? '(З Firestore)' : '(З пам\'яті)';

            cardsContainer.innerHTML = `
                <div class="card p-6 border-l-4 border-emerald-500">
                    <div class="flex justify-between items-start">
                        <div>
                            <p class="text-stone-500 text-sm font-medium">Загальний дохід</p>
                            <h3 class="text-2xl font-bold text-stone-800 mt-1">${formatter.format(totalIncome)} ₴</h3>
                        </div>
                        <div class="bg-emerald-100 p-2 rounded-lg text-emerald-600">
                            <i class="fa-solid fa-arrow-trend-up"></i>
                        </div>
                    </div>
                    <div class="mt-4 text-sm text-emerald-600 font-medium">
                        <i class="fa-solid fa-database"></i> ${dataOrigin}
                    </div>
                </div>

                <div class="card p-6 border-l-4 border-rose-500">
                    <div class="flex justify-between items-start">
                        <div>
                            <p class="text-stone-500 text-sm font-medium">Загальні витрати</p>
                            <h3 class="text-2xl font-bold text-stone-800 mt-1">${formatter.format(totalExpense)} ₴</h3>
                        </div>
                        <div class="bg-rose-100 p-2 rounded-lg text-rose-600">
                            <i class="fa-solid fa-arrow-trend-down"></i>
                        </div>
                    </div>
                    <div class="mt-4 text-sm text-rose-600 font-medium">
                        <i class="fa-solid fa-database"></i> ${dataOrigin}
                    </div>
                </div>

                <div class="card p-6 border-l-4 border-amber-500">
                    <div class="flex justify-between items-start">
                        <div>
                            <p class="text-stone-500 text-sm font-medium">Баланс</p>
                            <h3 class="text-2xl font-bold text-stone-800 mt-1">${formatter.format(balance)} ₴</h3>
                        </div>
                        <div class="bg-amber-100 p-2 rounded-lg text-amber-600">
                            <i class="fa-solid fa-piggy-bank"></i>
                        </div>
                    </div>
                    <div class="mt-4 text-sm ${balance >= 0 ? 'text-emerald-600' : 'text-rose-600'} font-medium">
                        <i class="fa-solid fa-database"></i> ${dataOrigin}
                    </div>
                </div>
            `;
        }

        function renderTopExpenses() {
            const topExpenses = state.transactions
                .filter(t => t.type === 'expense')
                .sort((a, b) => b.amount - a.amount)
                .slice(0, 5); // Top 5

            const tbody = document.getElementById('topExpensesBody');
            tbody.innerHTML = '';
            
            if (topExpenses.length === 0) {
                 tbody.innerHTML = '<tr><td colspan="4" class="px-6 py-4 text-center text-stone-500">Витрати відсутні.</td></tr>';
                 return;
            }

            topExpenses.forEach(t => {
                const row = document.createElement('tr');
                row.className = 'hover:bg-stone-50 transition-colors';
                
                let iconClass = 'fa-circle-question';
                if(t.category === 'Їжа') iconClass = 'fa-utensils';
                else if(t.category === 'Транспорт') iconClass = 'fa-car';
                else if(t.category === 'Житло') iconClass = 'fa-house';
                else if(t.category === 'Освіта') iconClass = 'fa-graduation-cap';
                else if(t.category === 'Техніка') iconClass = 'fa-laptop';

                row.innerHTML = `
                    <td class="px-6 py-4 flex items-center gap-3">
                        <div class="w-8 h-8 rounded bg-rose-100 text-rose-600 flex items-center justify-center"><i class="fa-solid ${iconClass}"></i></div>
                        <span>${t.category}</span>
                    </td>
                    <td class="px-6 py-4 text-stone-500">${t.date}</td>
                    <td class="px-6 py-4 text-stone-500">${t.note}</td>
                    <td class="px-6 py-4 text-right font-bold text-stone-800">- ${t.amount.toLocaleString('uk-UA', { minimumFractionDigits: 2 })} ₴</td>
                `;
                tbody.appendChild(row);
            });
        }


        // --- CHART CONFIG & UPDATE ---
        let barChartInstance = null;
        let pieChartInstance = null;

        function getChartData() {
            const expenseData = state.transactions.filter(t => t.type === 'expense');
            const categoryMap = expenseData.reduce((acc, t) => {
                acc[t.category] = (acc[t.category] || 0) + t.amount;
                return acc;
            }, {});

            const monthlyData = state.transactions.reduce((acc, t) => {
                const date = new Date(t.date);
                // Використовуємо місяць та рік для унікального ключа
                const monthYear = `${date.getFullYear()}-${date.getMonth().toString().padStart(2, '0')}`;
                
                if (!acc[monthYear]) {
                    acc[monthYear] = { 
                        income: 0, 
                        expense: 0, 
                        // Форматуємо для відображення
                        label: date.toLocaleString('uk-UA', { month: 'short', year: '2-digit' }) 
                    };
                }

                if (t.type === 'income') {
                    acc[monthYear].income += t.amount;
                } else {
                    acc[monthYear].expense += t.amount;
                }
                return acc;
            }, {});

            // Отримуємо останні 6 місяців, сортуючи за ключем YYYY-MM
            const sortedMonths = Object.keys(monthlyData).sort().slice(-6);

            const barLabels = sortedMonths.map(key => monthlyData[key].label);
            const incomeSeries = sortedMonths.map(key => monthlyData[key].income);
            const expenseSeries = sortedMonths.map(key => monthlyData[key].expense);


            return { categoryMap, barLabels, incomeSeries, expenseSeries };
        }


        function initCharts() {
            const { categoryMap, barLabels, incomeSeries, expenseSeries } = getChartData();
            
            // Bar Chart
            const barCtx = document.getElementById('barChart');
            if(barCtx) {
                barChartInstance = new Chart(barCtx.getContext('2d'), {
                    type: 'bar',
                    data: {
                        labels: barLabels, 
                        datasets: [
                            {
                                label: 'Доходи',
                                data: incomeSeries,
                                backgroundColor: '#10B981',
                                borderRadius: 4
                            },
                            {
                                label: 'Витрати',
                                data: expenseSeries,
                                backgroundColor: '#F43F5E',
                                borderRadius: 4
                            }
                        ]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: { position: 'bottom', labels: { usePointStyle: true, font: { family: 'Inter' } } }
                        },
                        scales: {
                            y: { beginAtZero: true, grid: { color: '#f3f4f6' }, ticks: { font: { family: 'Inter' } } },
                            x: { grid: { display: false }, ticks: { font: { family: 'Inter' } } }
                        }
                    }
                });
            }


            // Pie Chart
            const pieCtx = document.getElementById('pieChart');
            if(pieCtx) {
                pieChartInstance = new Chart(pieCtx.getContext('2d'), {
                    type: 'doughnut',
                    data: {
                        labels: Object.keys(categoryMap),
                        datasets: [{
                            data: Object.values(categoryMap),
                            backgroundColor: [
                                '#F59E0B', '#F87171', '#818CF8', '#34D399', '#60A5FA', '#9CA3AF', '#D1D5DB', '#FBCFE8'
                            ],
                            borderWidth: 0,
                            hoverOffset: 4
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        cutout: '65%',
                        plugins: {
                            legend: { position: 'right', labels: { usePointStyle: true, font: { family: 'Inter', size: 11 } } }
                        }
                    }
                });
            }
        }

        window.updateCharts = updateCharts;
        function updateCharts() {
             if (!barChartInstance || !pieChartInstance) {
                initCharts();
                return;
            }

            const { categoryMap, barLabels, incomeSeries, expenseSeries } = getChartData();
            
            // Update Pie Chart Data
            pieChartInstance.data.labels = Object.keys(categoryMap);
            pieChartInstance.data.datasets[0].data = Object.values(categoryMap);
            pieChartInstance.update();

            // Update Bar Chart Data
            barChartInstance.data.labels = barLabels;
            barChartInstance.data.datasets[0].data = incomeSeries;
            barChartInstance.data.datasets[1].data = expenseSeries;
            barChartInstance.update();
        }

        // --- INIT ---
        document.addEventListener('DOMContentLoaded', () => {
            document.getElementById('addTransactionForm').addEventListener('submit', submitNewTransaction);
            document.getElementById('typeFilter').addEventListener('change', applyFilters);
            document.getElementById('categoryFilter').addEventListener('change', applyFilters);
            document.getElementById('searchFilter').addEventListener('input', applyFilters);

            populateCategorySelects();
            
            switchView('dashboard'); 

            // Ініціалізація Firebase або Mock Mode
            initFirebase();
        });