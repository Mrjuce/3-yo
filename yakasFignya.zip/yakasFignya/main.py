import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split  # Розбиває дані на тренувальну та тестову вибірки
from sklearn.ensemble import RandomForestClassifier   # Класифікатор на базі ансамблю дерев (випадковий ліс)
from sklearn.preprocessing import LabelEncoder        # Кодує текстові мітки у числа
from sklearn.metrics import accuracy_score            # Обчислює точність передбачень моделі

# 1. Завантаження даних із CSV
# --------------------------------
df = pd.read_csv("digitaledu_users.csv")
print("1) Початковий вигляд даних (5 перших рядків):")
print(df.head())
print("\nІнформація про типи та пропуски:")
print(df.info())

# Обгрунтування:
# Ми отримали дані про користувачів — це перший крок, необхідно побачити,
# з чим працюємо: які колонки є, які типи даних, чи є пропуски.

# 2. Попередня очистка та трансформація даних
# --------------------------------------------

# Видаляємо колонку 'id' - унікальний ідентифікатор, не корисний для моделі
# Також видаляємо 'last_seen' — складна для аналізу колонка, пропускаємо поки
df = df.drop(columns=["id", "last_seen"])
print("\n2) Після видалення 'id' і 'last_seen':")
print(df.head())

# Обробляємо 'bdate' - перетворюємо дату народження на вік користувача
def convert_bdate(bdate):
    try:
        parts = bdate.split('.')
        if len(parts) == 3:
            day, month, year = map(int, parts)
            return 2025 - year  # вік на основі року народження
    except:
        return np.nan

df["age"] = df["bdate"].apply(convert_bdate)
df = df.drop(columns=["bdate"])
df["age"] = df["age"].fillna(df["age"].mean())

print("\n3) Додано колонку 'age' (вік), видалено 'bdate':")
print(df[["age"]].head())

# Обгрунтування:
# Вік — важлива ознака для класифікації поведінки користувача, наприклад, молодші чи старші
# користувачі можуть по-різному реагувати на рекламу.

# 3. Обробка пропусків і некоректних значень у числових колонках
int_cols = ["sex", "has_photo", "has_mobile", "followers_count", "graduation",
            "relation", "life_main", "people_main", "career_start", "career_end"]

for col in int_cols:
    if col in df.columns:
        # Заміна рядкових 'False'/'True' на 0/1, оскільки дані можуть містити ці значення
        df[col] = df[col].replace({'False': 0, 'True': 1})
        # Конвертація у числовий тип, пропуски заповнюємо 0
        df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0).astype(int)

print("\n4) Після обробки числових колонок (заміна 'False'/'True', пропуски):")
print(df[int_cols].head())

# Обгрунтування:
# Модель не зможе працювати з рядками 'False', тому перетворюємо їх у числа.
# Заповнення пропусків нулями допомагає уникнути помилок при тренуванні.

# 4. Обробка категоріальних змінних — кодуємо рядки у числа
cat_cols = ["education_form", "education_status", "langs", "occupation_type"]
for col in cat_cols:
    if col in df.columns:
        df[col] = df[col].fillna("unknown").astype(str)

label_encoders = {}
for col in cat_cols:
    le = LabelEncoder()
    df[col] = le.fit_transform(df[col])
    label_encoders[col] = le

print("\n5) Після кодування категоріальних змінних:")
print(df[cat_cols].head())

# Обгрунтування:
# Моделі машинного навчання потрібні числові дані, тому категоріальні перетворюємо у числа.

# 5. Заповнюємо залишкові пропуски у датафреймі (якщо є)
df = df.fillna(0)

# 6. Підготовка даних для моделі
X = df.drop(columns=["result"])  # ознаки
y = df["result"]                 # цільова змінна (купив курс або ні)

print(f"\n6) Розмірність ознак: {X.shape}, Розмірність цілі: {y.shape}")

# 7. Розбиття на тренувальну та тестову вибірки
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

print(f"\n7) Розмір тренувальної вибірки: {X_train.shape[0]} прикладів")
print(f"   Розмір тестової вибірки: {X_test.shape[0]} прикладів")

# 8. Навчання моделі Random Forest
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)
print("\n8) Модель натренована.")

# 9. Прогнозування на тесті та оцінка
y_pred = model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)

print(f"\n9) Точність моделі на тестовій вибірці: {accuracy:.3f}")

# 10. Приклади передбачень
comparison_df = pd.DataFrame({
    "Actual": y_test.values[:10],
    "Predicted": y_pred[:10]
})
print("\n10) Приклади прогнозів (Actual = фактичне, Predicted = передбачене):")
print(comparison_df)
