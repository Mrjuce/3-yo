key_switch_camera = "c"
key_switch_mode = "z"

key_forward = "w"
key_back = "s"
key_left = "a"
key_right = "d"
key_up = "e"
key_down = "q"

key_turn_left = "n"
key_turn_right = "m"

key_build = "b"
key_derstoy = "v"

class Hero():
    def __init__(self, pos, land):
        self.land = land
        self.mode = True
        self.hero = loader.loadModel("smiley")
        self.hero.setColor(1,0.5,0)
        self.hero.setScale(0.3)
        self.hero.setH(180)
        self.hero.setPos(pos)
        self.hero.reparentTo(render)
        self.cameraBind()
        self.accept_events()

    def cameraBind(self):
        base.disableMouse()
        base.camera.reparentTo(self.hero)
        base.camera.setPos(0,0,1.5)
        self.cameraOn= True

    def cameraUp(self):
        pos = self.hero.getPos()
        base.mouseInterfaceNode.setPos(-pos[0], -pos[1], -pos[2] - 3)
        base.camera.reparentTo(render)
        base.enableMouse()
        self.cameraOn = False


    def changeView(self):
        if self.cameraOn:
            self.cameraUp()
        else:
            self.cameraBind()

    def turn_left(self):
        self.hero.setH((self.hero.getH() + 5) %360)

    def turn_right(self):
        self.hero.setH((self.hero.getH() - 5) %360)

    def look_at(self,angle):
        x_from = round(self.hero.getX())
        y_from = round(self.hero.getY())
        z_from = round(self.hero.getZ())

        dx,dy = self.check_dir(angle)
        x_to = x_from + dx
        y_to = x_from + dy
        return x_to, y_to, z_from
    
    def just_move(self,angle):
        pos = self.look_at(angle)
        self.hero.setPos(pos)


    def move_to(self,angle):
        if self.mode:
            self.just_move(angle)
        else:
            self.try_move(angle)

    def forward(self):
        angle = (self.hero.getH()) % 360
        self.move_to(angle)


    def back(self):
        angle = (self.hero.getH() +180) % 360
        self.move_to(angle)


    def left(self):
        angle = (self.hero.getH() +90) % 360
        self.move_to(angle)

    def right(self):
        angle = (self.hero.getH() +270) % 360
        self.move_to(angle)

    def forward(self):
        angle = (self.hero.getH() +270) % 360
        self.move_to(angle)
    def check_dir(self, angle):

        '''    angle 0 (0 to 20)      -> Y - 1
            angle 45 (25 to 65)    -> X + 1, Y - 1
            angle 90 (70 to 110)   -> X + 1
            115 to 155             -> X + 1, Y + 1
            160 to 200             -> Y + 1
            205 to 245             -> X - 1, Y + 1
            250 to 290             -> X - 1
            290 to 335             -> X - 1, Y - 1
            340 and above          -> Y - 1'''
        if angle >= 0 and angle <= 20:
            return (0, -1)
        elif angle <= 65:
            return (1, -1)
        elif angle <= 110:
            return (1, 0)
        elif angle <= 155:
            return (1, 1)
        elif angle <= 200:
            return (0, 1)
        elif angle <= 245:
            return (-1, 1)
        elif angle <= 290:
            return (-1, 0)
        elif angle <= 335:
            return (-1, -1)
        else:
            return (0, -1)

    def up(self):
        self.hero.setZ(self.hero.getZ()+1)
    def up(self):
        self.hero.setZ(self.hero.getZ()-1)

    def changeMode(self):
        if self.mode == True:
            self.mode == False
        else:
            self.mode = True

    def try_move(self,angle):
        pos = self.look_at(angle)
        if self.land.isEmpry(pos):
            pos = self.land.findHighestEmpty(pos)
            self.hero.setPos(pos)
        else:
            pos = pos[0], pos[1], pos[2] + 1 
            if self.land.isEmpty(pos):
                self.hero.setPos(pos)

    def built(self):
        angle = self.hero.get() %360
        pos = self.look_at(pos)
        if self.mode:
            self.land.addBlock(pos)
        else:
            self.land.buildBlock(pos)

    def destroy(self):
        angle = self.hero.get() %360
        pos = self.look_at(pos)
        if self.mode:
            self.land.delBlock(pos)
        else:
            self.land.dellFromBlock(pos)

    def accept_events(self):

        base.accept(key_up, self.up)  
        base.accept(key_up + '-repeat', self.up)

        base.accept(key_down, self.back)  
        base.accept(key_down + '-repeat', self.back)

        base.accept(key_turn_left, self.turn_left)  # bind left turn key
        base.accept(key_turn_left + '-repeat', self.turn_left)  # bind repeated left turn
        base.accept(key_turn_right, self.turn_right)  # bind right turn key
        base.accept(key_turn_right + '-repeat', self.turn_right)  # bind repeated right turn

        base.accept(key_forward, self.forward)  # bind forward movement key
        base.accept(key_forward + '-repeat', self.forward)  # bind repeated forward
        base.accept(key_back, self.back)  # bind backward movement key
        base.accept(key_back + '-repeat', self.back)  # bind repeated backward
        base.accept(key_left, self.left) 
        base.accept(key_left + '-repeat', self.left) 
        base.accept(key_right, self.right)  
        base.accept(key_right + '-repeat', self.right)  

        base.accept(key_switch_camera, self.changeView)  
